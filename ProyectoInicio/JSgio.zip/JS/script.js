// alert("Hola Mundo");
// para comentar una linea /* */para comentar  parte de un codigo