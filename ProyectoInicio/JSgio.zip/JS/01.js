// alert("Primer Archivo");

let producto = "Juego de mesa UNO";
let disponible;
//parte de arriba declara la varible, parte abajo llama la variable
disponible= true;
disponible=false;

const categoria= "valor1"
/*esto de abajo no se puede hacer porque la var es una constante entonces no se puede
cambiar su valor
categoria= "juego"   */


let camiseta="red"
    pantalon="yellow"
    zapatos="blue";

    
console.log("variable producto:",producto);

console.log(disponible);    

console.log("camiseta", camiseta);
console.log("pantalon",pantalon);
console.log("zapatos", zapatos);

let product1= "DOOBLE";
    disponible1= false;
    categoria1 ="Juegos de Mesa"


console.log ("producto", producto1, categoria1, disponible1)

// let numero1;
// let 1numero;

const constante1=1;
console.log("ejercicio de asignacion de constantes:", constante1);
